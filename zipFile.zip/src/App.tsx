// src/App.tsx
import { Navigate, Route, Routes } from "react-router-dom"
import { useAuth } from "@/src/contexts/AuthContext"
import { AppLayout } from "@/src/layouts/AppLayout"
import { LoginPage } from "@/src/pages/LoginPage"
import { StudentDashboard } from "@/src/pages/student/StudentDashboard"
import { TeacherDashboard } from "@/src/pages/teacher/TeacherDashboard"
import { ApparitoratInscriptions } from "@/src/pages/apparitorat/ApparitoratInscriptions"
import { Placeholder } from "@/src/pages/Placeholder"
import type { ReactNode } from "react"

function RequireAuth({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth()
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RoleRedirect() {
  const { role, isAuthenticated } = useAuth()
  if (!isAuthenticated || !role) return <Navigate to="/login" replace />
  return <Navigate to={`/${role}/dashboard`} replace />
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={<RoleRedirect />} />

      <Route
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        {/* Étudiant */}
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route
          path="/student/schedule"
          element={<Placeholder title="Mon emploi du temps" />}
        />
        <Route path="/student/grades" element={<Placeholder title="Mes notes" />} />
        <Route
          path="/student/announcements"
          element={<Placeholder title="Annonces" />}
        />

        {/* Enseignant */}
        <Route path="/teacher/dashboard" element={<TeacherDashboard />} />
        <Route path="/teacher/courses" element={<Placeholder title="Mes cours" />} />
        <Route path="/teacher/grades" element={<Placeholder title="Saisie des notes" />} />
        <Route
          path="/teacher/schedule"
          element={<Placeholder title="Emploi du temps" />}
        />

        {/* Apparitorat */}
        <Route
          path="/apparitorat/dashboard"
          element={<Placeholder title="Tableau de bord Apparitorat" />}
        />
        <Route
          path="/apparitorat/inscriptions"
          element={<ApparitoratInscriptions />}
        />
        <Route path="/apparitorat/students" element={<Placeholder title="Étudiants" />} />

        {/* Secrétariat Faculté */}
        <Route
          path="/secretariat_faculte/dashboard"
          element={<Placeholder title="Tableau de bord Faculté" />}
        />
        <Route
          path="/secretariat_faculte/promotions"
          element={<Placeholder title="Promotions" />}
        />
        <Route
          path="/secretariat_faculte/courses"
          element={<Placeholder title="Cours" />}
        />

        {/* Secrétariat Général */}
        <Route
          path="/secretariat_general/dashboard"
          element={<Placeholder title="Tableau de bord Secrétariat Général" />}
        />
        <Route
          path="/secretariat_general/faculties"
          element={<Placeholder title="Facultés" />}
        />
        <Route
          path="/secretariat_general/announcements"
          element={<Placeholder title="Annonces" />}
        />

        {/* Rectorat */}
        <Route
          path="/rectorat/dashboard"
          element={<Placeholder title="Tableau de bord Rectorat" />}
        />
        <Route path="/rectorat/stats" element={<Placeholder title="Statistiques" />} />
        <Route path="/rectorat/faculties" element={<Placeholder title="Facultés" />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

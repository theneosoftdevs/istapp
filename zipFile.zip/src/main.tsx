// src/main.tsx
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import { BrowserRouter } from "react-router-dom"
import App from "@/src/App"
import { AuthProvider } from "@/src/contexts/AuthContext"
import { AppProvider } from "@/src/contexts/AppContext"
import { Toaster } from "@/components/ui/toaster"
import "@/src/index.css"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <App />
          <Toaster />
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
)
